from flask import Flask, render_template, request, redirect

app = Flask(__name__)

# Здесь будут храниться сообщения
messages = []

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        name = request.form['name']
        text = request.form['message']
        messages.append(f"{name}: {text}")
        return redirect('/')
    return render_template('index.html', messages=messages)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)

