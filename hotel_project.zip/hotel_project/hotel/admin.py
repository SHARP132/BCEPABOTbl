
from django.contrib import admin
from .models import (
    Client, RoomCategory, Amenity, CategoryAmenity,
    AdditionalService, Booking, BookingGuest, BookingService
)


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):

    list_display = ('full_name', 'phone', 'email', 'passport_number', 'discount_card_number')
    search_fields = ('full_name', 'phone', 'email', 'passport_number')
    list_filter = ('birth_date',)


@admin.register(RoomCategory)
class RoomCategoryAdmin(admin.ModelAdmin):

    list_display = ('name', 'room_type', 'bathroom_type', 'capacity', 'price_per_day')
    search_fields = ('name', 'room_type')
    list_filter = ('room_type', 'capacity')


@admin.register(Amenity)
class AmenityAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)


@admin.register(AdditionalService)
class AdditionalServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'unit')
    search_fields = ('name',)


class BookingGuestInline(admin.TabularInline):

    model = BookingGuest
    extra = 1


class BookingServiceInline(admin.TabularInline):

    model = BookingService
    extra = 1


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):

    list_display = ('pk', 'client', 'category', 'check_in_date', 'check_out_date', 'days', 'total_cost')
    search_fields = ('client__full_name', 'category__name')
    list_filter = ('check_in_date', 'breakfast_included', 'dinner_included')
    inlines = [BookingGuestInline, BookingServiceInline]
    readonly_fields = ('days', 'total_cost', 'created_at')
