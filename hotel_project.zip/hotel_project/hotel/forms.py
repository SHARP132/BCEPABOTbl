

from django import forms
from .models import Client, RoomCategory, Booking, AdditionalService


class ClientForm(forms.ModelForm):


    class Meta:
        model = Client
        fields = [
            'full_name', 'phone', 'email',
            'birth_date', 'birth_place',
            'passport_series', 'passport_number',
            'passport_issue_date', 'passport_issued_by',
            'address', 'discount_card_number', 'car_number',
        ]
        widgets = {

            'birth_date': forms.DateInput(
                attrs={'type': 'date', 'class': 'form-control'}),
            'passport_issue_date': forms.DateInput(
                attrs={'type': 'date', 'class': 'form-control'}),
            # Многострочный адрес
            'address': forms.Textarea(
                attrs={'rows': 3, 'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for field in self.fields.values():
            if not isinstance(field.widget, (forms.DateInput, forms.Textarea)):
                field.widget.attrs.setdefault('class', 'form-control')

    def clean_phone(self):

        phone = self.cleaned_data.get('phone', '')
        # Допускаем пустое значение
        if phone and len(phone) < 7:
            raise forms.ValidationError('Введите корректный номер телефона.')
        return phone


class RoomCategoryForm(forms.ModelForm):



    ROOM_TYPE_CHOICES = [
        ('', '— Выберите тип —'),
        ('Одноместный', 'Одноместный'),
        ('Двухместный', 'Двухместный'),
        ('Двуспальный', 'Двуспальный'),
        ('Апартаменты', 'Апартаменты'),
        ('Студия', 'Студия'),
    ]

    BATHROOM_TYPE_CHOICES = [
        ('', '— Выберите тип санузла —'),
        ('Душевая', 'Душевая'),
        ('Ванная', 'Ванная'),
        ('Совмещённый', 'Совмещённый'),
        ('Отдельный', 'Отдельный'),
    ]

    room_type = forms.ChoiceField(
        choices=ROOM_TYPE_CHOICES,
        label='Тип номера',
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'}),
    )
    bathroom_type = forms.ChoiceField(
        choices=BATHROOM_TYPE_CHOICES,
        label='Тип санузла',
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'}),
    )

    class Meta:
        model = RoomCategory
        fields = [
            'name', 'description', 'price_per_day',
            'room_type', 'bathroom_type', 'capacity',
        ]
        widgets = {
            'description': forms.Textarea(
                attrs={'rows': 3, 'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            if name not in ('room_type', 'bathroom_type'):
                field.widget.attrs.setdefault('class', 'form-control')


class BookingForm(forms.ModelForm):


    class Meta:
        model = Booking
        fields = [
            'client', 'category',
            'check_in_date', 'check_out_date',
            'breakfast_included', 'dinner_included',
        ]
        widgets = {

            'client': forms.Select(attrs={'class': 'form-select'}),
            'category': forms.Select(attrs={'class': 'form-select'}),
            # Даты — HTML5 date-picker
            'check_in_date': forms.DateInput(
                attrs={'type': 'date', 'class': 'form-control'}),
            'check_out_date': forms.DateInput(
                attrs={'type': 'date', 'class': 'form-control'}),
            # Чекбоксы Bootstrap
            'breakfast_included': forms.CheckboxInput(
                attrs={'class': 'form-check-input'}),
            'dinner_included': forms.CheckboxInput(
                attrs={'class': 'form-check-input'}),
        }

    def clean(self):

        cleaned_data = super().clean()
        check_in = cleaned_data.get('check_in_date')
        check_out = cleaned_data.get('check_out_date')

        if check_in and check_out:
            if check_out <= check_in:
                raise forms.ValidationError(
                    'Дата выезда должна быть позже даты заезда.')
        return cleaned_data


class AdditionalServiceForm(forms.ModelForm):


    UNIT_CHOICES = [
        ('шт.', 'шт.'),
        ('чел.', 'чел.'),
        ('услуга', 'услуга'),
        ('сутки', 'сутки'),
        ('час', 'час'),
    ]

    unit = forms.ChoiceField(
        choices=UNIT_CHOICES,
        label='Единица измерения',
        widget=forms.Select(attrs={'class': 'form-select'}),
    )

    class Meta:
        model = AdditionalService
        fields = ['name', 'description', 'price', 'unit']
        widgets = {
            'description': forms.Textarea(
                attrs={'rows': 3, 'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            if name != 'unit':
                field.widget.attrs.setdefault('class', 'form-control')
