
from django.db import models


class Client(models.Model):


    full_name = models.CharField('ФИО', max_length=200)
    phone = models.CharField('Телефон', max_length=20, blank=True)
    email = models.EmailField('E-mail', max_length=100, blank=True)
    birth_date = models.DateField('Дата рождения', null=True, blank=True)
    birth_place = models.CharField('Место рождения', max_length=200, blank=True)
    passport_series = models.CharField('Серия паспорта', max_length=10, blank=True)
    passport_number = models.CharField('Номер паспорта', max_length=20, blank=True)
    passport_issue_date = models.DateField('Дата выдачи паспорта', null=True, blank=True)
    passport_issued_by = models.CharField('Паспорт выдан', max_length=200, blank=True)
    address = models.TextField('Адрес проживания', blank=True)
    discount_card_number = models.CharField('Номер дисконтной карты', max_length=50, blank=True)
    car_number = models.CharField('Гос. номер автомобиля', max_length=20, blank=True)

    class Meta:
        verbose_name = 'Клиент'
        verbose_name_plural = 'Клиенты'
        ordering = ['full_name']

    def __str__(self):
        return self.full_name


class RoomCategory(models.Model):


    name = models.CharField('Название категории', max_length=100)
    description = models.TextField('Описание', blank=True)
    price_per_day = models.DecimalField('Цена за сутки', max_digits=10, decimal_places=2)
    room_type = models.CharField('Тип номера', max_length=50, blank=True)
    bathroom_type = models.CharField('Тип санузла', max_length=50, blank=True)
    capacity = models.IntegerField('Вместимость (чел.)', default=1)

    class Meta:
        verbose_name = 'Категория номера'
        verbose_name_plural = 'Категории номеров'
        ordering = ['name']

    def __str__(self):
        return f'{self.name} ({self.price_per_day} руб./сут.)'


class Amenity(models.Model):


    name = models.CharField('Удобство', max_length=100, unique=True)

    class Meta:
        verbose_name = 'Удобство'
        verbose_name_plural = 'Удобства'
        ordering = ['name']

    def __str__(self):
        return self.name


class CategoryAmenity(models.Model):


    category = models.ForeignKey(RoomCategory, on_delete=models.CASCADE,
                                 verbose_name='Категория')
    amenity = models.ForeignKey(Amenity, on_delete=models.CASCADE,
                                verbose_name='Удобство')

    class Meta:
        verbose_name = 'Удобство категории'
        verbose_name_plural = 'Удобства категорий'
        unique_together = ('category', 'amenity')

    def __str__(self):
        return f'{self.category} — {self.amenity}'


class AdditionalService(models.Model):


    name = models.CharField('Название услуги', max_length=100)
    description = models.TextField('Описание', blank=True)
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2)
    unit = models.CharField('Единица измерения', max_length=50, default='шт.')

    class Meta:
        verbose_name = 'Дополнительная услуга'
        verbose_name_plural = 'Дополнительные услуги'
        ordering = ['name']

    def __str__(self):
        return f'{self.name} — {self.price} руб./{self.unit}'


class Booking(models.Model):


    client = models.ForeignKey(Client, on_delete=models.RESTRICT,
                               verbose_name='Клиент')
    category = models.ForeignKey(RoomCategory, on_delete=models.RESTRICT,
                                 verbose_name='Категория номера')
    check_in_date = models.DateField('Дата заезда')
    check_out_date = models.DateField('Дата выезда')
    # Количество суток вычисляется автоматически при сохранении
    days = models.IntegerField('Кол-во суток', null=True, blank=True)
    breakfast_included = models.BooleanField('Завтрак включён', default=False)
    dinner_included = models.BooleanField('Ужин включён', default=False)
    total_cost = models.DecimalField('Итоговая стоимость', max_digits=12,
                                     decimal_places=2, null=True, blank=True)
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)

    class Meta:
        verbose_name = 'Бронирование'
        verbose_name_plural = 'Бронирования'
        ordering = ['-created_at']

    def save(self, *args, **kwargs):

        if self.check_in_date and self.check_out_date:
            self.days = (self.check_out_date - self.check_in_date).days
            if self.category_id and self.days > 0:
                self.total_cost = self.category.price_per_day * self.days
        super().save(*args, **kwargs)

    def __str__(self):
        return f'Бронь #{self.pk} — {self.client} ({self.check_in_date} … {self.check_out_date})'


class BookingGuest(models.Model):


    booking = models.ForeignKey(Booking, on_delete=models.CASCADE,
                                verbose_name='Бронирование',
                                related_name='guests')
    full_name = models.CharField('ФИО гостя', max_length=200)
    birth_date = models.DateField('Дата рождения', null=True, blank=True)
    extra_bed = models.BooleanField('Доп. кровать', default=False)
    breakfast = models.BooleanField('Завтрак', default=False)
    dinner = models.BooleanField('Ужин', default=False)

    class Meta:
        verbose_name = 'Гость бронирования'
        verbose_name_plural = 'Гости бронирования'

    def __str__(self):
        return f'{self.full_name} (бронь #{self.booking_id})'


class BookingService(models.Model):


    booking = models.ForeignKey(Booking, on_delete=models.CASCADE,
                                verbose_name='Бронирование',
                                related_name='services')
    service = models.ForeignKey(AdditionalService, on_delete=models.CASCADE,
                                verbose_name='Услуга')
    quantity = models.IntegerField('Количество', default=1)

    price_at_time = models.DecimalField('Цена на момент брони', max_digits=10,
                                        decimal_places=2, null=True, blank=True)

    class Meta:
        verbose_name = 'Услуга бронирования'
        verbose_name_plural = 'Услуги бронирования'

    def save(self, *args, **kwargs):

        if not self.price_at_time and self.service_id:
            self.price_at_time = self.service.price
        super().save(*args, **kwargs)

    def __str__(self):
        return f'{self.service.name} × {self.quantity} (бронь #{self.booking_id})'
