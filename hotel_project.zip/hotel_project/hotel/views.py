"""
Представления (views) приложения гостиницы.

Структура страниц:
  /                     — главная (дашборд со сводкой)
  /clients/             — список клиентов с поиском и фильтрацией
  /clients/add/         — добавление клиента
  /clients/<pk>/edit/   — редактирование клиента
  /clients/<pk>/delete/ — удаление клиента
  /rooms/               — список категорий номеров
  /rooms/add/           — добавление категории
  /rooms/<pk>/edit/     — редактирование категории
  /rooms/<pk>/delete/   — удаление категории
  /bookings/            — список бронирований с поиском
  /bookings/add/        — добавление бронирования
  /bookings/<pk>/edit/  — редактирование бронирования
  /bookings/<pk>/delete/— удаление бронирования
  /services/            — дополнительные услуги
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q, Count
from django.utils import timezone

from .models import Client, RoomCategory, Booking, AdditionalService
from .forms import ClientForm, RoomCategoryForm, BookingForm, AdditionalServiceForm


# ──────────────────────────────────────────────
#  ГЛАВНАЯ СТРАНИЦА
# ──────────────────────────────────────────────

def dashboard(request):

    today = timezone.now().date()


    total_clients = Client.objects.count()
    total_bookings = Booking.objects.count()
    active_bookings = Booking.objects.filter(
        check_in_date__lte=today,
        check_out_date__gte=today,
    ).count()
    total_rooms = RoomCategory.objects.count()


    recent_bookings = Booking.objects.select_related('client', 'category').order_by('-created_at')[:5]


    recent_clients = Client.objects.order_by('-id')[:5]

    context = {
        'total_clients': total_clients,
        'total_bookings': total_bookings,
        'active_bookings': active_bookings,
        'total_rooms': total_rooms,
        'recent_bookings': recent_bookings,
        'recent_clients': recent_clients,
        'today': today,
    }
    return render(request, 'hotel/dashboard.html', context)



def client_list(request):

    qs = Client.objects.all()


    search = request.GET.get('q', '').strip()
    has_card = request.GET.get('has_card', '')


    if search:
        qs = qs.filter(
            Q(full_name__icontains=search) |
            Q(phone__icontains=search) |
            Q(email__icontains=search) |
            Q(passport_number__icontains=search)
        )


    if has_card == '1':
        qs = qs.exclude(discount_card_number='')
    elif has_card == '0':
        qs = qs.filter(discount_card_number='')

    context = {
        'clients': qs,
        'search': search,
        'has_card': has_card,
        'total': qs.count(),
    }
    return render(request, 'hotel/client_list.html', context)


def client_add(request):

    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            client = form.save()
            messages.success(request, f'Клиент «{client.full_name}» успешно добавлен.')
            return redirect('client_list')
        else:
            messages.error(request, 'Исправьте ошибки в форме.')
    else:
        form = ClientForm()

    return render(request, 'hotel/client_form.html', {
        'form': form,
        'title': 'Добавить клиента',
        'btn_label': 'Добавить',
    })


def client_edit(request, pk):

    client = get_object_or_404(Client, pk=pk)

    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            messages.success(request, f'Данные клиента «{client.full_name}» обновлены.')
            return redirect('client_list')
        else:
            messages.error(request, 'Исправьте ошибки в форме.')
    else:
        form = ClientForm(instance=client)

    return render(request, 'hotel/client_form.html', {
        'form': form,
        'title': f'Редактировать: {client.full_name}',
        'btn_label': 'Сохранить',
        'object': client,
    })


def client_delete(request, pk):

    client = get_object_or_404(Client, pk=pk)

    if request.method == 'POST':
        name = client.full_name
        client.delete()
        messages.success(request, f'Клиент «{name}» удалён.')
        return redirect('client_list')

    return render(request, 'hotel/confirm_delete.html', {
        'object': client,
        'object_name': client.full_name,
        'cancel_url': 'client_list',
    })



def room_list(request):

    qs = RoomCategory.objects.all()

    search = request.GET.get('q', '').strip()
    capacity = request.GET.get('capacity', '')

    if search:
        qs = qs.filter(
            Q(name__icontains=search) |
            Q(room_type__icontains=search) |
            Q(description__icontains=search)
        )


    if capacity.isdigit():
        qs = qs.filter(capacity__gte=int(capacity))

    context = {
        'rooms': qs,
        'search': search,
        'capacity': capacity,
        'total': qs.count(),
    }
    return render(request, 'hotel/room_list.html', context)


def room_add(request):

    if request.method == 'POST':
        form = RoomCategoryForm(request.POST)
        if form.is_valid():
            room = form.save()
            messages.success(request, f'Категория «{room.name}» добавлена.')
            return redirect('room_list')
        else:
            messages.error(request, 'Исправьте ошибки в форме.')
    else:
        form = RoomCategoryForm()

    return render(request, 'hotel/room_form.html', {
        'form': form,
        'title': 'Добавить категорию номера',
        'btn_label': 'Добавить',
    })


def room_edit(request, pk):

    room = get_object_or_404(RoomCategory, pk=pk)

    if request.method == 'POST':
        form = RoomCategoryForm(request.POST, instance=room)
        if form.is_valid():
            form.save()
            messages.success(request, f'Категория «{room.name}» обновлена.')
            return redirect('room_list')
        else:
            messages.error(request, 'Исправьте ошибки в форме.')
    else:
        form = RoomCategoryForm(instance=room)

    return render(request, 'hotel/room_form.html', {
        'form': form,
        'title': f'Редактировать: {room.name}',
        'btn_label': 'Сохранить',
        'object': room,
    })


def room_delete(request, pk):

    room = get_object_or_404(RoomCategory, pk=pk)

    if request.method == 'POST':
        name = room.name
        room.delete()
        messages.success(request, f'Категория «{name}» удалена.')
        return redirect('room_list')

    return render(request, 'hotel/confirm_delete.html', {
        'object': room,
        'object_name': room.name,
        'cancel_url': 'room_list',
    })



def booking_list(request):

    today = timezone.now().date()
    qs = Booking.objects.select_related('client', 'category').all()

    search = request.GET.get('q', '').strip()
    status = request.GET.get('status', '')

    if search:
        qs = qs.filter(
            Q(client__full_name__icontains=search) |
            Q(category__name__icontains=search)
        )


    if status == 'active':
        qs = qs.filter(check_in_date__lte=today, check_out_date__gte=today)
    elif status == 'upcoming':
        qs = qs.filter(check_in_date__gt=today)
    elif status == 'past':
        qs = qs.filter(check_out_date__lt=today)

    context = {
        'bookings': qs,
        'search': search,
        'status': status,
        'total': qs.count(),
        'today': today,
    }
    return render(request, 'hotel/booking_list.html', context)


def booking_add(request):

    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save()
            messages.success(
                request,
                f'Бронирование #{booking.pk} для «{booking.client}» создано.'
            )
            return redirect('booking_list')
        else:
            messages.error(request, 'Исправьте ошибки в форме.')
    else:
        form = BookingForm()

    return render(request, 'hotel/booking_form.html', {
        'form': form,
        'title': 'Новое бронирование',
        'btn_label': 'Забронировать',
    })


def booking_edit(request, pk):

    booking = get_object_or_404(Booking, pk=pk)

    if request.method == 'POST':
        form = BookingForm(request.POST, instance=booking)
        if form.is_valid():
            form.save()
            messages.success(request, f'Бронирование #{booking.pk} обновлено.')
            return redirect('booking_list')
        else:
            messages.error(request, 'Исправьте ошибки в форме.')
    else:
        form = BookingForm(instance=booking)

    return render(request, 'hotel/booking_form.html', {
        'form': form,
        'title': f'Редактировать бронирование #{booking.pk}',
        'btn_label': 'Сохранить',
        'object': booking,
    })


def booking_delete(request, pk):

    booking = get_object_or_404(Booking, pk=pk)

    if request.method == 'POST':
        booking.delete()
        messages.success(request, f'Бронирование #{pk} удалено.')
        return redirect('booking_list')

    return render(request, 'hotel/confirm_delete.html', {
        'object': booking,
        'object_name': str(booking),
        'cancel_url': 'booking_list',
    })



def service_list(request):

    qs = AdditionalService.objects.all()

    search = request.GET.get('q', '').strip()
    if search:
        qs = qs.filter(
            Q(name__icontains=search) |
            Q(description__icontains=search)
        )

    context = {
        'services': qs,
        'search': search,
        'total': qs.count(),
    }
    return render(request, 'hotel/service_list.html', context)


def service_add(request):

    if request.method == 'POST':
        form = AdditionalServiceForm(request.POST)
        if form.is_valid():
            svc = form.save()
            messages.success(request, f'Услуга «{svc.name}» добавлена.')
            return redirect('service_list')
    else:
        form = AdditionalServiceForm()

    return render(request, 'hotel/service_form.html', {
        'form': form,
        'title': 'Добавить услугу',
        'btn_label': 'Добавить',
    })


def service_edit(request, pk):

    svc = get_object_or_404(AdditionalService, pk=pk)

    if request.method == 'POST':
        form = AdditionalServiceForm(request.POST, instance=svc)
        if form.is_valid():
            form.save()
            messages.success(request, f'Услуга «{svc.name}» обновлена.')
            return redirect('service_list')
    else:
        form = AdditionalServiceForm(instance=svc)

    return render(request, 'hotel/service_form.html', {
        'form': form,
        'title': f'Редактировать: {svc.name}',
        'btn_label': 'Сохранить',
    })


def service_delete(request, pk):

    svc = get_object_or_404(AdditionalService, pk=pk)

    if request.method == 'POST':
        name = svc.name
        svc.delete()
        messages.success(request, f'Услуга «{name}» удалена.')
        return redirect('service_list')

    return render(request, 'hotel/confirm_delete.html', {
        'object': svc,
        'object_name': svc.name,
        'cancel_url': 'service_list',
    })
