import io
import base64
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from django.shortcuts import render
from django.utils import timezone
from .models import Booking, RoomCategory

def charts(request):
    today = timezone.now().date()
    chart_type = request.GET.get('type', 'bar')

    categories = RoomCategory.objects.all()
    labels = [c.name for c in categories]

    bookings_by_cat = []
    for c in categories:
        count = Booking.objects.filter(category=c).count()
        bookings_by_cat.append(count)

    fig, ax = plt.subplots(figsize=(9, 5))
    colors = ['#4f7ef8', '#34c38f', '#f46a6a', '#f1b44c', '#74788d', '#50a5f1']

    if chart_type == 'bar':
        ax.bar(labels, bookings_by_cat, color=colors[:len(labels)])
        ax.set_title('Заселяемость номеров (гистограмма)')
        ax.set_xlabel('Категория')
        ax.set_ylabel('Количество броней')

    elif chart_type == 'line':
        from collections import defaultdict
        monthly = defaultdict(int)
        for b in Booking.objects.all():
            key = b.check_in_date.strftime('%Y-%m')
            monthly[key] += 1
        sorted_keys = sorted(monthly.keys())[-12:]
        values = [monthly[k] for k in sorted_keys]
        ax.plot(sorted_keys, values, marker='o', color='#4f7ef8', linewidth=2)
        ax.set_title('Бронирования по месяцам (линейный)')
        ax.set_xlabel('Месяц')
        ax.set_ylabel('Количество броней')
        plt.xticks(rotation=45)

    elif chart_type == 'pie':
        non_zero = [(l, v) for l, v in zip(labels, bookings_by_cat) if v > 0]
        if non_zero:
            pie_labels, pie_values = zip(*non_zero)
            ax.pie(pie_values, labels=pie_labels, colors=colors[:len(pie_labels)],
                   autopct='%1.1f%%', startangle=140)
        ax.set_title('Заселяемость по категориям (круговая)')

    plt.tight_layout()
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=120)
    plt.close()
    buf.seek(0)
    img_b64 = base64.b64encode(buf.read()).decode('utf-8')

    return render(request, 'hotel/charts.html', {
        'img': img_b64,
        'chart_type': chart_type,
    })
