from django.shortcuts import render

def index(request):
    """Главная страница"""
    return render(request, 'ecoapp/index.html')

def product_detail(request):
    """Страница товара"""
    return render(request, 'ecoapp/product.html')