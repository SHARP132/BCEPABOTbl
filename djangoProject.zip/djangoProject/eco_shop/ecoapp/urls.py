from django.urls import path
from . import views

app_name = 'ecoapp'

urlpatterns = [
    path('', views.index, name='index'),
    path('product/', views.product_detail, name='product_detail'),
]