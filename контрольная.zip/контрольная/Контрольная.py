#11 Вариант Музыкальный плеер – управление плейлистами и треками
#Пользователю выподает рандомная музыка, он может ее лайкнуть, может пропустить
import random
class Music:
    playlist = []

    #Какая песня выпадет
     #Выводит название песни и ее длину
    def __init__(self):
        self.playlist = []
        self.current_track = None

    # Включить рандомную музыку
    def play_music(self):
        tracks = [
            ("monster", "3:11"),
            ("douchland", "4:53"),
            ("КиШ", "1:37")
        ]
        self.current_track = random.choice(tracks)
        name, length = self.current_track
        print(f"\nСейчас играет песня: {name}, длина: {length}")
        
        

     # Пропуск песни
    def skip(self):
        print("\n Пропуск песни")
        self.play_music()

    # Лайк
    def like(self):
        if self.current_track:
            self.playlist.append(self.current_track)
            print(f"\nПесня добавлена в плейлист")
        else:
            print("\nСейчас ничего не играет")

    # Удалить из плейлиста
    def delete(self):
        if self.playlist:
            removed = self.playlist.pop()
            print(f"\nПесня {removed[0]} удалена из плейлиста")
        else:
            print("\nПлейлист пуст")
        
    

class Main:
    player = Music()
    print("У вас в руках плеер")
    print("1 - включить музыку")
    print("2 - пропуск")
    print("3 - занести в плейлист")
    print("4 - удалить из плейлиста")
    while True:
        choice = input("\nВы выбрали: ")
        if choice == "1":
            player.play_music()
        elif choice == "2":
            player.skip()
        elif choice == "3":
            player.like()
        elif choice == "4":
            player.delete()
        else:
            print(" Неверный выбор")
    




    

    

    
    



